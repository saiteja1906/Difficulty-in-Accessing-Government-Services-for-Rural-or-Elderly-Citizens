import openai
from config import OPENAI_API_KEY

openai.api_key = OPENAI_API_KEY

def detect_intent(query):
    """Detect the intent of the user query."""
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Identify the intent of this query: {query}",
        max_tokens=150
    )
    return response.choices[0].text.strip()
