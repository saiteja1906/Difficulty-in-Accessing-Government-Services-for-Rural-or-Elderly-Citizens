MYSQL_CONFIG = {
    'host': 'localhost',
    'user': 'yashunaidu2612gmail.com',
    'password': 'Yashu@2005',
    'database': 'easygov_db'
}

OPENAI_API_KEY = "your_openai_api_key"
from your_directory.config import MYSQL_CONFIG
from ..config import MYSQL_CONFIG
