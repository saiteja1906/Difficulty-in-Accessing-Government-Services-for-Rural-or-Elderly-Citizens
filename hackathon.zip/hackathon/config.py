MYSQL_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Vinnu@9866',
    'database': 'easygov_db'
}

OPENAI_API_KEY = "your_openai_api_key"
